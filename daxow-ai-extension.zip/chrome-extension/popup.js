// ══════════════════════════════════════════════════
//  DAXOW AI ASSISTANT - Chrome Extension
//  Connects to same Supabase DB as Daxow Portal
// ══════════════════════════════════════════════════

// ─── CONFIG ──────────────────────────────────────
// Replace these with your actual keys (same as your .env.local)
const SUPABASE_URL     = "https://knqtjanxjwfjfrwoater.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtucXRqYW54andmamZyd29hdGVyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQyOTczMjQsImV4cCI6MjA2OTg3MzMyNH0.r0l1zFcBQdx4tBxpp6413r5MXAmy-1Ew2TnQ8QNVB2g";
const N8N_WEBHOOK_URL  = "https://automation.sitconnect.net/webhook/5ef25141-0607-40d4-9966-ece519329797";

// ─── DOM REFS ─────────────────────────────────────
const loginScreen   = document.getElementById("login-screen");
const chatScreen    = document.getElementById("chat-screen");
const loginForm     = document.getElementById("login-form");
const emailInput    = document.getElementById("email");
const passwordInput = document.getElementById("password");
const loginBtn      = document.getElementById("login-btn");
const loginBtnText  = document.getElementById("login-btn-text");
const loginSpinner  = document.getElementById("login-spinner");
const loginError    = document.getElementById("login-error");
const logoutBtn     = document.getElementById("logout-btn");
const userEmailBadge = document.getElementById("user-email-badge");
const messagesEl    = document.getElementById("messages");
const chatInput     = document.getElementById("chat-input");
const sendBtn       = document.getElementById("send-btn");

// ─── SUPABASE CLIENT (no npm, pure fetch) ─────────
const supabase = {
  auth: {
    signIn: async (email, password) => {
      const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "apikey": SUPABASE_ANON_KEY,
        },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error_description || data.msg || "Login failed");
      return data;
    },
  }
};

// ─── SESSION STORAGE ──────────────────────────────
// Supports both Chrome Extension (chrome.storage) and regular browser (localStorage)
const SESSION_KEY = "daxow_ext_session";
const isChromeExt = typeof chrome !== "undefined" && chrome.storage?.local;

async function saveSession(session) {
  if (isChromeExt) {
    return new Promise(resolve => chrome.storage.local.set({ [SESSION_KEY]: session }, resolve));
  } else {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  }
}

async function getSession() {
  if (isChromeExt) {
    return new Promise(resolve => {
      chrome.storage.local.get(SESSION_KEY, result => resolve(result[SESSION_KEY] || null));
    });
  } else {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  }
}

async function clearSession() {
  if (isChromeExt) {
    return new Promise(resolve => chrome.storage.local.remove(SESSION_KEY, resolve));
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

// ─── INIT ──────────────────────────────────────────
async function init() {
  const session = await getSession();
  if (session?.user?.id) {
    showChat(session);
  } else {
    showLogin();
  }
}

// ─── SCREENS ──────────────────────────────────────
function showLogin() {
  loginScreen.classList.remove("hidden");
  chatScreen.classList.add("hidden");
  loginError.classList.add("hidden");
  emailInput.value = "";
  passwordInput.value = "";
}

function showChat(session) {
  loginScreen.classList.add("hidden");
  chatScreen.classList.remove("hidden");
  userEmailBadge.textContent = session.user.email || "Agent";
}

// ─── LOGIN ─────────────────────────────────────────
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const email    = emailInput.value.trim();
  const password = passwordInput.value;

  if (!email || !password) return;

  // Loading state
  loginBtnText.textContent = "Signing in...";
  loginSpinner.classList.remove("hidden");
  loginBtn.disabled = true;
  loginError.classList.add("hidden");

  try {
    const data = await supabase.auth.signIn(email, password);

    // Build session object
    const session = {
      access_token:  data.access_token,
      refresh_token: data.refresh_token,
      user: {
        id:    data.user.id,
        email: data.user.email,
      }
    };

    await saveSession(session);
    showChat(session);

  } catch (err) {
    loginError.textContent = err.message || "Invalid email or password. Please try again.";
    loginError.classList.remove("hidden");
  } finally {
    loginBtnText.textContent = "Sign In";
    loginSpinner.classList.add("hidden");
    loginBtn.disabled = false;
  }
});

// ─── LOGOUT ────────────────────────────────────────
logoutBtn.addEventListener("click", async () => {
  await clearSession();
  showLogin();
});

// ─── CHAT ──────────────────────────────────────────
function formatTime(date) {
  return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function appendMessage({ role, text }) {
  const div      = document.createElement("div");
  const bubble   = document.createElement("div");
  const timeSpan = document.createElement("span");

  div.classList.add("message");
  bubble.classList.add("msg-bubble");
  timeSpan.classList.add("msg-time");
  timeSpan.textContent = formatTime(new Date());

  if (role === "user") {
    div.classList.add("user-message");
    bubble.textContent = text;
  } else {
    div.classList.add("ai-message");
    // Support basic markdown-like line breaks
    bubble.innerHTML = text.replace(/\n/g, "<br/>");
  }

  div.appendChild(bubble);
  div.appendChild(timeSpan);
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

function showTyping() {
  const div    = document.createElement("div");
  const bubble = document.createElement("div");
  div.classList.add("message", "ai-message");
  bubble.classList.add("typing-bubble");
  bubble.innerHTML = `
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>
    <div class="typing-dot"></div>
  `;
  div.appendChild(bubble);
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return div;
}

async function sendMessage() {
  const text = chatInput.value.trim();
  if (!text) return;

  // Clear input & resize
  chatInput.value = "";
  chatInput.style.height = "auto";
  sendBtn.disabled = true;

  // Show user message
  appendMessage({ role: "user", text });

  // Show typing
  const typingEl = showTyping();

  try {
    const session = await getSession();
    if (!session) { showLogin(); return; }

    const response = await fetch(N8N_WEBHOOK_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        agent_id: session.user.id,    // ← Used in n8n to filter by agency_id
        email:    session.user.email,
        message:  text,
      }),
    });

    if (!response.ok) throw new Error(`Webhook error: ${response.status}`);

    const data = await response.json();

    // n8n should return { output: "..." } or { message: "..." } or { response: "..." }
    const aiText = data.output || data.message || data.response || data.text
                || JSON.stringify(data);

    typingEl.remove();
    appendMessage({ role: "ai", text: aiText });

  } catch (err) {
    typingEl.remove();
    appendMessage({
      role: "ai",
      text: `⚠️ Sorry, I encountered an error: ${err.message}\nPlease try again.`,
    });
  } finally {
    sendBtn.disabled = false;
    chatInput.focus();
  }
}

// ─── SEND TRIGGERS ─────────────────────────────────
sendBtn.addEventListener("click", sendMessage);

chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Auto-resize textarea
chatInput.addEventListener("input", () => {
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
});

// ─── START ─────────────────────────────────────────
init();
